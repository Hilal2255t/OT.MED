import { create } from 'zustand';
import { Medication, StaffMember, WithdrawTransaction } from '../types';

interface MedicationStore {
  medications: Medication[];
  withdrawHistory: WithdrawTransaction[];
  lastDeletedHistory: WithdrawTransaction[];
  lastDeletionRange: { from: string; to: string } | null;
  searchTerm: string;
  editingId: string | null;
  staffMember: StaffMember | null;
  
  addMedication: (medication: Omit<Medication, 'id'>) => void;
  updateMedication: (id: string, medication: Omit<Medication, 'id'>) => void;
  deleteMedication: (id: string) => void;
  withdrawMedication: (id: string, amount: number, patientName: string, patientID: string) => boolean;
  returnMedication: (id: string, amount: number) => void;
  clearHistoryByDateRange: (from: string, to: string) => number;
  undoLastHistoryDeletion: () => number;
  setSearchTerm: (term: string) => void;
  setEditingId: (id: string | null) => void;
  setStaffMember: (staff: StaffMember | null) => void;
  loadFromStorage: () => void;
  saveToStorage: () => void;
  getFilteredMedications: () => Medication[];
}

const STORAGE_KEY = 'medications';
const HISTORY_KEY = 'withdrawHistory';
const STAFF_KEY = 'currentStaff';
const BACKUP_SUFFIX = '_backup';

export const useMedicationStore = create<MedicationStore>((set, get) => ({
  medications: [],
  withdrawHistory: [],
  lastDeletedHistory: [],
  lastDeletionRange: null,
  searchTerm: '',
  editingId: null,
  staffMember: null,

  addMedication: (medication) => {
    const newMedication: Medication = {
      ...medication,
      id: Date.now().toString(),
    };
    
    set((state) => ({
      medications: [...state.medications, newMedication],
    }));
    
    get().saveToStorage();
  },

  updateMedication: (id, medication) => {
    const { staffMember, medications } = get();

    const existing = medications.find((med) => med.id === id);
    if (!existing) return;

    const changes: string[] = [];
    if (existing.name !== medication.name) changes.push(`Name: "${existing.name}" → "${medication.name}"`);
    if (existing.dosage !== medication.dosage) changes.push(`Dosage: "${existing.dosage}" → "${medication.dosage}"`);
    if (existing.pharmacyCode !== medication.pharmacyCode)
      changes.push(`Code: "${existing.pharmacyCode}" → "${medication.pharmacyCode}"`);
    if (existing.mainStock !== medication.mainStock)
      changes.push(`Main stock: ${existing.mainStock} → ${medication.mainStock}`);
    if (existing.quantity !== medication.quantity)
      changes.push(`Quantity: ${existing.quantity} → ${medication.quantity}`);
    if (existing.expirationDate !== medication.expirationDate)
      changes.push(
        `Expiry: ${new Date(existing.expirationDate).toLocaleDateString()} → ${new Date(
          medication.expirationDate
        ).toLocaleDateString()}`
      );
    if (existing.location !== medication.location)
      changes.push(`Location: "${existing.location}" → "${medication.location}"`);

    const summary = changes.length ? changes.join(' | ') : 'No changes recorded';

    const transaction: WithdrawTransaction = {
      id: Date.now(),
      type: 'edit',
      medicationName: existing.name,
      dosage: existing.dosage,
      pharmacyCode: existing.pharmacyCode,
      amount: 0,
      previousQuantity: existing.quantity,
      newQuantity: medication.quantity,
      location: medication.location,
      staffName: staffMember?.name,
      staffID: staffMember?.staffID,
      changeSummary: summary,
      date: new Date().toISOString(),
      dateFormatted: new Date().toLocaleString(),
    };

    set((state) => ({
      medications: state.medications.map((med) => (med.id === id ? { ...medication, id } : med)),
      withdrawHistory: [transaction, ...state.withdrawHistory],
    }));
    
    get().saveToStorage();
  },

  deleteMedication: (id) => {
    set((state) => ({
      medications: state.medications.filter((med) => med.id !== id),
    }));
    
    get().saveToStorage();
  },

  withdrawMedication: (id, amount, patientName, patientID) => {
    const state = get();
    const medication = state.medications.find((med) => med.id === id);
    
    if (!medication || amount > medication.quantity) {
      return false;
    }

    const transaction: WithdrawTransaction = {
      id: Date.now(),
      type: 'withdraw',
      medicationName: medication.name,
      dosage: medication.dosage,
      pharmacyCode: medication.pharmacyCode,
      amount,
      previousQuantity: medication.quantity,
      newQuantity: medication.quantity - amount,
      location: medication.location,
      staffName: state.staffMember?.name,
      staffID: state.staffMember?.staffID,
      patientName: patientName.trim(),
      patientID: patientID.trim(),
      date: new Date().toISOString(),
      dateFormatted: new Date().toLocaleString(),
    };

    set((state) => ({
      medications: state.medications.map((med) =>
        med.id === id ? { ...med, quantity: med.quantity - amount } : med
      ),
      withdrawHistory: [transaction, ...state.withdrawHistory],
      lastDeletedHistory: [],
      lastDeletionRange: null,
    }));

    get().saveToStorage();
    return true;
  },

  returnMedication: (id, amount) => {
    const state = get();
    const medication = state.medications.find((med) => med.id === id);
    
    if (!medication) return;

    const transaction: WithdrawTransaction = {
      id: Date.now(),
      type: 'return',
      medicationName: medication.name,
      dosage: medication.dosage,
      pharmacyCode: medication.pharmacyCode,
      amount,
      previousQuantity: medication.quantity,
      newQuantity: medication.quantity + amount,
      location: medication.location,
      staffName: state.staffMember?.name,
      staffID: state.staffMember?.staffID,
      date: new Date().toISOString(),
      dateFormatted: new Date().toLocaleString(),
    };

    set((state) => ({
      medications: state.medications.map((med) =>
        med.id === id ? { ...med, quantity: med.quantity + amount } : med
      ),
      withdrawHistory: [transaction, ...state.withdrawHistory],
      lastDeletedHistory: [],
      lastDeletionRange: null,
    }));

    get().saveToStorage();
  },

  clearHistoryByDateRange: (from, to) => {
    const state = get();
    const fromDate = new Date(from).setHours(0, 0, 0, 0);
    const toDate = new Date(to).setHours(23, 59, 59, 999);

    const deletedEntries = state.withdrawHistory.filter((transaction) => {
      const transactionTime = new Date(transaction.date).getTime();
      return transactionTime >= fromDate && transactionTime <= toDate;
    });

    const remaining = state.withdrawHistory.filter((transaction) => {
      const transactionTime = new Date(transaction.date).getTime();
      return transactionTime < fromDate || transactionTime > toDate;
    });

    set({
      withdrawHistory: remaining,
      lastDeletedHistory: deletedEntries,
      lastDeletionRange: deletedEntries.length ? { from, to } : null,
    });

    get().saveToStorage();

    return deletedEntries.length;
  },

  undoLastHistoryDeletion: () => {
    const { lastDeletedHistory, withdrawHistory } = get();
    if (!lastDeletedHistory.length) {
      return 0;
    }

    const combined = [...lastDeletedHistory, ...withdrawHistory].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    set({
      withdrawHistory: combined,
      lastDeletedHistory: [],
      lastDeletionRange: null,
    });

    get().saveToStorage();
    return lastDeletedHistory.length;
  },

  setSearchTerm: (term) => {
    set({ searchTerm: term });
  },

  setEditingId: (id) => {
    set({ editingId: id });
  },

  setStaffMember: (staff) => {
    set({ staffMember: staff });
    try {
      if (staff) {
        localStorage.setItem(STAFF_KEY, JSON.stringify(staff));
      } else {
        const { medications, withdrawHistory } = get();
        localStorage.removeItem(STAFF_KEY);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(medications));
        localStorage.setItem(HISTORY_KEY, JSON.stringify(withdrawHistory));
        localStorage.setItem(STORAGE_KEY + BACKUP_SUFFIX, JSON.stringify(medications));
        localStorage.setItem(HISTORY_KEY + BACKUP_SUFFIX, JSON.stringify(withdrawHistory));
      }
    } catch (error) {
      console.error('Failed to persist staff member:', error);
    }
  },

  loadFromStorage: () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      const storedHistory = localStorage.getItem(HISTORY_KEY);
      const storedStaff = localStorage.getItem(STAFF_KEY);
      
      if (stored) {
        const medications = JSON.parse(stored);
        set({ medications });
      }
      
      if (storedHistory) {
        const withdrawHistory = JSON.parse(storedHistory);
        set({ withdrawHistory });
      }

      if (storedStaff) {
        const staffMember = JSON.parse(storedStaff);
        set({ staffMember });
      }

      set({ lastDeletedHistory: [], lastDeletionRange: null });
    } catch (error) {
      console.error('Failed to load from storage:', error);
    }
  },

  saveToStorage: () => {
    try {
      const { medications, withdrawHistory, staffMember } = get();
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(medications));
      localStorage.setItem(HISTORY_KEY, JSON.stringify(withdrawHistory));
      
      if (staffMember) {
        localStorage.setItem(STAFF_KEY, JSON.stringify(staffMember));
      }
      
      localStorage.setItem(STORAGE_KEY + BACKUP_SUFFIX, JSON.stringify(medications));
      localStorage.setItem(HISTORY_KEY + BACKUP_SUFFIX, JSON.stringify(withdrawHistory));
      localStorage.setItem('last_save_time', new Date().toISOString());
    } catch (error) {
      console.error('Failed to save to storage:', error);
    }
  },

  getFilteredMedications: () => {
    const { medications, searchTerm } = get();
    
    if (!searchTerm) return medications;
    
    const term = searchTerm.toLowerCase();
    return medications.filter(
      (med) =>
        med.name.toLowerCase().includes(term) ||
        med.dosage.toLowerCase().includes(term) ||
        med.pharmacyCode.toLowerCase().includes(term) ||
        med.location.toLowerCase().includes(term)
    );
  },
}));
