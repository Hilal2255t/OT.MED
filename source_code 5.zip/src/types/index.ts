export interface Medication {
  id: string;
  name: string;
  dosage: string;
  pharmacyCode: string;
  mainStock: number;
  quantity: number;
  expirationDate: string;
  location: string;
}

export interface StaffMember {
  name: string;
  staffID: string;
}

export interface WithdrawTransaction {
  id: number;
  type: 'withdraw' | 'return' | 'edit';
  medicationName: string;
  dosage: string;
  pharmacyCode: string;
  amount: number;
  previousQuantity: number;
  newQuantity: number;
  location: string;
  staffName?: string;
  staffID?: string;
  patientName?: string;
  patientID?: string;
  changeSummary?: string;
  date: string;
  dateFormatted: string;
}

export interface MedicationStatus {
  class: 'status-good' | 'status-warning' | 'status-expired';
  text: 'GOOD' | 'EXPIRING SOON' | 'EXPIRED';
  rowClass: '' | 'expiring-soon' | 'expired';
}

export type LocationOption = 
  | 'Room 1' 
  | 'Room 2' 
  | 'Room 3' 
  | 'Room 4' 
  | 'Room 5' 
  | 'Room 6' 
  | 'Room 7' 
  | 'RECOVERY 1' 
  | 'RECOVERY 2' 
  | 'Other';
