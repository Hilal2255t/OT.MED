import React, { useMemo, useState } from 'react';
import { useMedicationStore } from '../store/medicationStore';
import { Printer, RotateCcw, Trash2, X } from 'lucide-react';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose }) => {
  const {
    withdrawHistory,
    clearHistoryByDateRange,
    undoLastHistoryDeletion,
    lastDeletionRange,
  } = useMedicationStore();
  
  const [filters, setFilters] = useState({
    medName: '',
    patientName: '',
    patientID: '',
    dateFrom: '',
    dateTo: '',
    type: 'all' as 'all' | 'withdraw' | 'return',
  });

  const filteredHistory = useMemo(() => {
    return withdrawHistory.filter((transaction) => {
      let matches = true;

      if (filters.medName && !transaction.medicationName.toLowerCase().includes(filters.medName.toLowerCase())) {
        matches = false;
      }

      if (filters.patientName && transaction.patientName && !transaction.patientName.toLowerCase().includes(filters.patientName.toLowerCase())) {
        matches = false;
      }

      if (filters.patientID && transaction.patientID && !transaction.patientID.toLowerCase().includes(filters.patientID.toLowerCase())) {
        matches = false;
      }

      if (filters.type !== 'all' && transaction.type !== filters.type) {
        matches = false;
      }

      if (filters.dateFrom) {
        const transDate = new Date(transaction.date).setHours(0, 0, 0, 0);
        const fromDate = new Date(filters.dateFrom).setHours(0, 0, 0, 0);
        if (transDate < fromDate) matches = false;
      }

      if (filters.dateTo) {
        const transDate = new Date(transaction.date).setHours(0, 0, 0, 0);
        const toDate = new Date(filters.dateTo).setHours(0, 0, 0, 0);
        if (transDate > toDate) matches = false;
      }

      return matches;
    });
  }, [withdrawHistory, filters]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDeleteRange = () => {
    if (!filters.dateFrom || !filters.dateTo) {
      alert('Please select both From Date and To Date before deleting.');
      return;
    }

    const confirmation = confirm(
      `Are you sure you want to delete history entries between ${
        new Date(filters.dateFrom).toLocaleDateString()
      } and ${new Date(filters.dateTo).toLocaleDateString()}?`
    );

    if (!confirmation) return;

    const deletedCount = clearHistoryByDateRange(filters.dateFrom, filters.dateTo);

    alert(
      deletedCount > 0
        ? `Successfully deleted ${deletedCount} entr${deletedCount === 1 ? 'y' : 'ies'}.`
        : 'No entries were found in the selected date range.'
    );
  };

  const handleUndo = () => {
    const restored = undoLastHistoryDeletion();

    alert(
      restored > 0
        ? `Restored ${restored} entr${restored === 1 ? 'y' : 'ies'} back into the history.`
        : 'There is no deletion to undo.'
    );
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-md overflow-auto p-4 md:p-10">
      <div className="bg-white/95 backdrop-blur-xl rounded-[26px] border border-white/60 shadow-[0_50px_90px_-45px_rgba(79,70,229,0.55)] w-full max-w-6xl max-h-[90vh] flex flex-col">
        <div className="px-8 py-6 md:px-12 md:py-8 border-b border-gray-100 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.42em] text-indigo-500">Audit trail</p>
            <h2 className="text-3xl font-semibold text-gray-900 mt-1">Withdraw & Return History</h2>
            <p className="text-sm text-gray-500 mt-2 max-w-2xl">
              Review all activity including withdrawals, returns, and medication edits with full staff attribution.
            </p>
          </div>
          <div className="flex items-center gap-3 flex-wrap justify-end">
            <button
              onClick={handleUndo}
              className={`transition-all px-4 py-2 rounded-full flex items-center gap-2 text-sm font-semibold shadow-sm ${
                lastDeletionRange
                  ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
              disabled={!lastDeletionRange}
            >
              <RotateCcw className="w-4 h-4" />
              Undo delete
            </button>
            {lastDeletionRange && (
              <span className="text-xs bg-indigo-50 text-indigo-500 px-3 py-1 rounded-full border border-indigo-100">
                Deleted: {new Date(lastDeletionRange.from).toLocaleDateString()} – {new Date(lastDeletionRange.to).toLocaleDateString()}
              </span>
            )}
            <button
              onClick={handlePrint}
              className="bg-white text-indigo-600 px-4 py-2 rounded-full text-sm font-semibold border border-indigo-200 shadow-sm hover:bg-indigo-50 transition-colors flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print
            </button>
            <button
              onClick={handleDeleteRange}
              className="bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded-full text-sm font-semibold shadow flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Delete range
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-7 h-7" />
            </button>
          </div>
        </div>

        <div className="px-8 md:px-12 py-8 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">
                Medication
              </label>
              <input
                type="text"
                name="medName"
                value={filters.medName}
                onChange={handleFilterChange}
                placeholder="Search medication"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">
                Patient name
              </label>
              <input
                type="text"
                name="patientName"
                value={filters.patientName}
                onChange={handleFilterChange}
                placeholder="Search patient name"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">
                Patient ID
              </label>
              <input
                type="text"
                name="patientID"
                value={filters.patientID}
                onChange={handleFilterChange}
                placeholder="Search patient ID"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">From date</label>
              <input
                type="date"
                name="dateFrom"
                value={filters.dateFrom}
                onChange={handleFilterChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">To date</label>
              <input
                type="date"
                name="dateTo"
                value={filters.dateTo}
                onChange={handleFilterChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs uppercase tracking-[0.32em] text-gray-500 mb-2">
                Transaction type
              </label>
              <select
                name="type"
                value={filters.type}
                onChange={handleFilterChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-indigo-500 focus:ring focus:ring-indigo-200/60 transition-all shadow-sm"
              >
                <option value="all">All transactions</option>
                <option value="withdraw">Withdrawals only</option>
                <option value="return">Returns only</option>
                <option value="edit">Edits only</option>
              </select>
            </div>
          </div>

          {filteredHistory.length === 0 ? (
            <div className="text-center py-16 text-gray-500">
              <h3 className="text-xl font-semibold mb-2">
                {withdrawHistory.length === 0
                  ? 'No transaction history'
                  : 'No matching transactions'}
              </h3>
              <p>
                {withdrawHistory.length === 0
                  ? 'Withdrawal and return transactions will appear here'
                  : 'Try adjusting your filters'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl shadow-lg">
              <table className="w-full bg-white">
                <thead className="bg-gray-800 text-white">
                  <tr>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      #
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Date & Time
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Type
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Medication
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Dosage
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Code
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Amount
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Patient Name
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Patient ID
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Change summary / Processed By
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Previous Qty
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      New Qty
                    </th>
                    <th className="px-3 py-3 text-left font-semibold border-b-2 border-gray-700">
                      Location
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredHistory.map((transaction, index) => (
                    <tr
                      key={transaction.id}
                      className={`border-b border-gray-200 ${
                        index % 2 === 0 ? 'bg-gray-50' : 'bg-white'
                      } hover:bg-blue-50 transition-colors`}
                    >
                      <td className="px-3 py-3 text-gray-800 font-semibold">{index + 1}</td>
                      <td className="px-3 py-3 text-gray-800 font-medium">
                        {transaction.dateFormatted}
                      </td>
                      <td className="px-3 py-3">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                            transaction.type === 'withdraw'
                              ? 'bg-orange-100 text-orange-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {transaction.type === 'withdraw' ? '📤 WITHDRAW' : '📥 RETURN'}
                        </span>
                      </td>
                      <td className="px-3 py-3 text-gray-800 font-semibold">
                        {transaction.medicationName}
                      </td>
                      <td className="px-3 py-3 text-gray-800">{transaction.dosage}</td>
                      <td className="px-3 py-3 text-gray-800">{transaction.pharmacyCode}</td>
                      <td className="px-3 py-3 text-gray-800 font-semibold">
                        {transaction.type === 'edit' ? '—' : transaction.amount}
                      </td>
                      {transaction.type === 'withdraw' ? (
                        <>
                          <td className="px-3 py-3 text-gray-800 font-semibold">
                            {transaction.patientName || 'N/A'}
                          </td>
                          <td className="px-3 py-3 text-gray-800">
                            {transaction.patientID || 'N/A'}
                          </td>
                        </>
                      ) : (
                        <td colSpan={2} className="px-3 py-3 text-center text-gray-400">
                          —
                        </td>
                      )}
                      <td className="px-3 py-3 text-gray-800">
                        {transaction.type === 'edit' ? (
                          <div className="flex flex-col gap-1">
                            <span className="text-sm text-gray-700">{transaction.changeSummary}</span>
                            {transaction.staffName && (
                              <span className="text-xs text-gray-500">
                                Edited by {transaction.staffName} (ID: {transaction.staffID ?? 'N/A'})
                              </span>
                            )}
                          </div>
                        ) : transaction.staffName ? (
                          <div className="flex flex-col">
                            <span className="font-semibold">{transaction.staffName}</span>
                            <span className="text-xs text-gray-500">ID: {transaction.staffID}</span>
                          </div>
                        ) : (
                          <span className="text-gray-400">Unknown</span>
                        )}
                      </td>
                      <td className="px-3 py-3 text-gray-800">
                        {transaction.type === 'edit' ? transaction.previousQuantity : transaction.previousQuantity}
                      </td>
                      <td className="px-3 py-3 text-gray-800">
                        {transaction.type === 'edit' ? transaction.newQuantity : transaction.newQuantity}
                      </td>
                      <td className="px-3 py-3 text-gray-800">{transaction.location}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
