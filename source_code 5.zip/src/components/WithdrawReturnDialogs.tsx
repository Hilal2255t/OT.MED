import React from 'react';
import { useMedicationStore } from '../store/medicationStore';

interface WithdrawReturnDialogsProps {
  onComplete: () => void;
}

export const useWithdrawReturnDialogs = () => {
  const { medications, withdrawMedication, returnMedication } = useMedicationStore();

  const handleWithdraw = (id: string) => {
    const med = medications.find((m) => m.id === id);
    if (!med) return;

    const patientName = prompt(
      `📤 WITHDRAW MEDICATION\n\nMedication: ${med.name} (${med.dosage})\nCurrent Quantity: ${med.quantity}\n\n━━━━━━━━━━━━━━━━━━━━━━\nEnter Patient Name:`
    );

    if (patientName === null || patientName.trim() === '') {
      alert('Patient name is required to withdraw medication.');
      return;
    }

    const patientID = prompt(
      `📤 WITHDRAW MEDICATION\n\nMedication: ${med.name} (${med.dosage})\nPatient Name: ${patientName}\n\n━━━━━━━━━━━━━━━━━━━━━━\nEnter Patient ID:`
    );

    if (patientID === null || patientID.trim() === '') {
      alert('Patient ID is required to withdraw medication.');
      return;
    }

    const withdrawAmountStr = prompt(
      `📤 WITHDRAW MEDICATION\n\nMedication: ${med.name} (${med.dosage})\nPatient Name: ${patientName}\nPatient ID: ${patientID}\nCurrent Quantity: ${med.quantity}\n\n━━━━━━━━━━━━━━━━━━━━━━\nEnter amount to withdraw:`
    );

    if (withdrawAmountStr === null) return;

    const amount = parseInt(withdrawAmountStr);

    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid positive number.');
      return;
    }

    if (amount > med.quantity) {
      alert(`Cannot withdraw ${amount}. Only ${med.quantity} available.`);
      return;
    }

    const success = withdrawMedication(id, amount, patientName, patientID);
    
    if (success) {
      const newQuantity = med.quantity - amount;
      alert(
        `✅ WITHDRAWAL SUCCESSFUL\n\nMedication: ${med.name}\nAmount Withdrawn: ${amount}\nPatient: ${patientName}\nPatient ID: ${patientID}\nRemaining Quantity: ${newQuantity}`
      );
    }
  };

  const handleReturn = (id: string) => {
    const med = medications.find((m) => m.id === id);
    if (!med) return;

    const returnAmountStr = prompt(
      `Return to: ${med.name} (${med.dosage})\nCurrent Quantity: ${med.quantity}\n\nEnter amount to return:`
    );

    if (returnAmountStr === null) return;

    const amount = parseInt(returnAmountStr);

    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid positive number.');
      return;
    }

    returnMedication(id, amount);
    
    const newQuantity = med.quantity + amount;
    alert(`Successfully returned ${amount} unit(s).\nNew Total: ${newQuantity}`);
  };

  return { handleWithdraw, handleReturn };
};
