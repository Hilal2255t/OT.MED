import React, { useState, useEffect } from 'react';
import { useMedicationStore } from '../store/medicationStore';
import { LocationOption } from '../types';
import { ChevronDown } from 'lucide-react';

const LOCATIONS: LocationOption[] = [
  'Room 1',
  'Room 2',
  'Room 3',
  'Room 4',
  'Room 5',
  'Room 6',
  'Room 7',
  'RECOVERY 1',
  'RECOVERY 2',
  'Other',
];

export const MedicationForm: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    dosage: '',
    pharmacyCode: '',
    mainStock: '',
    quantity: '',
    expirationDate: '',
    location: '' as LocationOption | '',
    customLocation: '',
  });

  const { addMedication, updateMedication, editingId, setEditingId, medications } = useMedicationStore();

  useEffect(() => {
    if (editingId) {
      const medication = medications.find((m) => m.id === editingId);
      if (medication) {
        setIsOpen(true);
        
        const isStandardLocation = LOCATIONS.slice(0, -1).includes(medication.location as LocationOption);
        setFormData({
          name: medication.name,
          dosage: medication.dosage,
          pharmacyCode: medication.pharmacyCode,
          mainStock: medication.mainStock.toString(),
          quantity: medication.quantity.toString(),
          expirationDate: medication.expirationDate,
          location: isStandardLocation ? (medication.location as LocationOption) : 'Other',
          customLocation: isStandardLocation ? '' : medication.location,
        });
      }
    }
  }, [editingId, medications]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const finalLocation = formData.location === 'Other' ? formData.customLocation : formData.location;

    const medicationData = {
      name: formData.name,
      dosage: formData.dosage,
      pharmacyCode: formData.pharmacyCode,
      mainStock: parseInt(formData.mainStock, 10),
      quantity: parseInt(formData.quantity, 10),
      expirationDate: formData.expirationDate,
      location: finalLocation,
    };

    if (editingId) {
      updateMedication(editingId, medicationData);
      setEditingId(null);
    } else {
      addMedication(medicationData);
    }

    resetForm();
    setIsOpen(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      dosage: '',
      pharmacyCode: '',
      mainStock: '',
      quantity: '',
      expirationDate: '',
      location: '',
      customLocation: '',
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    resetForm();
    setIsOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="mb-10">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full px-8 py-4 rounded-2xl font-semibold text-lg flex items-center justify-between md:justify-center gap-3 transition-all duration-200 shadow-[0_20px_50px_-25px_rgba(79,70,229,0.55)] border border-transparent bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-[0_25px_65px_-25px_rgba(79,70,229,0.75)] ${
          isOpen ? 'ring-2 ring-white/40' : ''
        }`}
      >
        <span className="flex items-center gap-3">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/15 font-semibold text-xl">
            {isOpen ? '✦' : '➕'}
          </span>
          <span>{editingId ? 'Update existing medication' : 'Add new medication'}</span>
        </span>
        <ChevronDown
          className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <div className="mt-6 bg-white/80 backdrop-blur rounded-2xl border border-gray-100 shadow-[0_32px_65px_-40px_rgba(79,70,229,0.45)] animate-[slideDown_0.3s_ease-out]">
          <div className="px-6 md:px-10 py-8 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">
                {editingId ? 'Edit Medication' : 'Add New Medication'}
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                Record dosage, stock, expiration, and location details accurately.
              </p>
            </div>
            {editingId && (
              <button
                type="button"
                onClick={handleCancel}
                className="text-xs uppercase tracking-[0.22em] text-gray-400 hover:text-gray-600"
              >
                Cancel edit
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="px-6 md:px-10 py-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">
                  Medication Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">Dosage</label>
                <input
                  type="text"
                  name="dosage"
                  value={formData.dosage}
                  onChange={handleChange}
                  placeholder="e.g., 500mg, 10ml"
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">
                  Pharmacy Code
                </label>
                <input
                  type="text"
                  name="pharmacyCode"
                  value={formData.pharmacyCode}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">Main Stock</label>
                <input
                  type="number"
                  name="mainStock"
                  value={formData.mainStock}
                  onChange={handleChange}
                  min="0"
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">Quantity</label>
                <input
                  type="number"
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleChange}
                  min="0"
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">
                  Expiration Date
                </label>
                <input
                  type="date"
                  name="expirationDate"
                  value={formData.expirationDate}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                />
              </div>

              <div className="flex flex-col">
                <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">Location</label>
                <select
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                >
                  <option value="">Select Location</option>
                  {LOCATIONS.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              {formData.location === 'Other' && (
                <div className="flex flex-col">
                  <label className="font-semibold mb-2 text-xs uppercase tracking-[0.28em] text-gray-500">
                    Custom Location
                  </label>
                  <input
                    type="text"
                    name="customLocation"
                    value={formData.customLocation}
                    onChange={handleChange}
                    placeholder="Enter custom location"
                    required
                    className="px-4 py-3 rounded-xl border border-gray-200 bg-white focus:border-purple-500 focus:ring focus:ring-purple-200/60 transition-all shadow-sm"
                  />
                </div>
              )}
            </div>

            <div className="flex flex-col md:flex-row gap-3 justify-end">
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-8 py-3 rounded-xl font-semibold tracking-wide uppercase text-xs shadow-lg shadow-purple-500/30 hover:shadow-purple-500/40 transition-all hover:-translate-y-[1px]"
              >
                {editingId ? 'Save changes' : 'Add medication'}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl border border-gray-200 text-gray-600 text-xs uppercase tracking-wide font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
