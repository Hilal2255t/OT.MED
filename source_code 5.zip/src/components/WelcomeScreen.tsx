import React from 'react';
import { ArrowRight, Pill, ShieldCheck } from 'lucide-react';

interface WelcomeScreenProps {
  onEnter: (staff: { name: string; staffID: string }) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnter }) => {
  const [name, setName] = React.useState('');
  const [staffID, setStaffID] = React.useState('');
  const [error, setError] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedID = staffID.trim();

    if (!trimmedName || !trimmedID) {
      setError('Please enter both staff name and staff ID to continue.');
      return;
    }

    setError('');
    onEnter({ name: trimmedName, staffID: trimmedID });
  };

  return (
    <div className="relative min-h-screen md:min-h-[720px] bg-gradient-to-br from-purple-700 via-indigo-700 to-purple-900 text-white overflow-hidden flex items-center">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('/assets/youware-bg.png')] opacity-20 mix-blend-screen"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-purple-800/80 via-indigo-900/70 to-black/70 backdrop-blur-sm"></div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 py-16 lg:py-20 flex flex-col gap-12">
        <div className="flex items-center gap-3 text-sm uppercase tracking-[0.4em] text-white/70">
          <ShieldCheck className="w-5 h-5" />
          Trusted OT Workflow
        </div>

        <div className="grid md:grid-cols-[1.1fr_0.9fr] gap-12 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight">
              Welcome to the OT Medication Tracker
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-xl">
              Keep your operating theatre inventory organised, compliant, and ready for every procedure.
              Monitor stock levels, track expirations, and log patient withdrawals with medical-grade precision.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-white/75">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20">
                <Pill className="w-4 h-4" /> Real-time inventory overview
              </span>
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20">
                <ShieldCheck className="w-4 h-4" /> Secure patient-linked history
              </span>
            </div>
          </div>

          <div className="bg-white/10 rounded-3xl border border-white/20 backdrop-blur-xl p-8 space-y-6 shadow-2xl">
            <div className="rounded-2xl bg-white/5 border border-white/15 p-6 space-y-4">
              <p className="text-base text-white/80">
                This tool streamlines medication handling from stocking to withdrawal and return, ensuring
                traceability and accountability across your theatre team.
              </p>
              <ul className="space-y-3 text-sm text-white/70">
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full bg-emerald-300"></span>
                  Auto-save with backup snapshots
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full bg-amber-300"></span>
                  Expiry alerts and visual status cues
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full bg-sky-300"></span>
                  Full withdrawal and return history
                </li>
              </ul>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="staffName" className="text-sm font-semibold text-white/80">
                  Staff Name
                </label>
                <input
                  id="staffName"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 focus:outline-none focus:ring-2 focus:ring-emerald-400 placeholder:text-white/50"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="staffID" className="text-sm font-semibold text-white/80">
                  Staff ID
                </label>
                <input
                  id="staffID"
                  type="text"
                  value={staffID}
                  onChange={(e) => setStaffID(e.target.value)}
                  placeholder="Enter your staff ID"
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 focus:outline-none focus:ring-2 focus:ring-emerald-400 placeholder:text-white/50"
                />
              </div>
              {error && (
                <p className="text-sm text-rose-200 bg-rose-500/10 border border-rose-400/40 px-3 py-2 rounded-lg">
                  {error}
                </p>
              )}
              <button
                type="submit"
                className="w-full bg-emerald-400 hover:bg-emerald-300 text-slate-900 font-semibold py-4 px-6 rounded-2xl flex items-center justify-center gap-2 transition-transform duration-200 hover:-translate-y-1 shadow-lg"
              >
                Sign in
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
            <p className="text-xs text-white/50 text-center">
              Tip: Staff identity will be attached to every withdrawal and return log during this session.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
