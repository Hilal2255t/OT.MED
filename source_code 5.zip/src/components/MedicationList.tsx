import React from 'react';
import { useMedicationStore } from '../store/medicationStore';
import { Medication, MedicationStatus } from '../types';
import { Edit2, Trash2, ArrowUpFromLine, ArrowDownToLine } from 'lucide-react';

const DELETE_PASSWORD = 'De2255';

const getDaysUntilExpiration = (expirationDate: string): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expDate = new Date(expirationDate);
  expDate.setHours(0, 0, 0, 0);
  const diffTime = expDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

const getStatus = (daysUntilExpiration: number): MedicationStatus => {
  if (daysUntilExpiration < 0) {
    return { class: 'status-expired', text: 'EXPIRED', rowClass: 'expired' };
  } else if (daysUntilExpiration <= 30) {
    return { class: 'status-warning', text: 'EXPIRING SOON', rowClass: 'expiring-soon' };
  } else {
    return { class: 'status-good', text: 'GOOD', rowClass: '' };
  }
};

const getExpirationText = (daysUntilExpiration: number): string => {
  if (daysUntilExpiration < 0) {
    return `${Math.abs(daysUntilExpiration)} days ago`;
  } else if (daysUntilExpiration === 0) {
    return 'Today';
  } else if (daysUntilExpiration === 1) {
    return 'Tomorrow';
  } else {
    return `${daysUntilExpiration} days`;
  }
};

interface MedicationListProps {
  onWithdraw: (id: string) => void;
  onReturn: (id: string) => void;
}

export const MedicationList: React.FC<MedicationListProps> = ({ onWithdraw, onReturn }) => {
  const { getFilteredMedications, deleteMedication, setEditingId, searchTerm } = useMedicationStore();
  
  const medications = getFilteredMedications();

  const sortedMedications = [...medications].sort((a, b) => {
    const daysA = getDaysUntilExpiration(a.expirationDate);
    const daysB = getDaysUntilExpiration(b.expirationDate);
    return daysA - daysB;
  });

  const handleDelete = (id: string) => {
    let attempts = 0;
    
    while (attempts < 3) {
      const enteredPassword = prompt('Enter delete password to remove this medication:');
      
      if (enteredPassword === null) {
        return;
      }
      
      if (enteredPassword === DELETE_PASSWORD) {
        if (confirm('Are you sure you want to delete this medication?')) {
          deleteMedication(id);
          alert('Medication deleted successfully.');
        }
        return;
      }
      
      attempts++;
      if (attempts < 3) {
        alert(`Incorrect password! You have ${3 - attempts} attempt(s) remaining.`);
      }
    }
    
    alert('Too many failed attempts. Deletion cancelled.');
  };

  if (sortedMedications.length === 0) {
    return (
      <div className="text-center py-16 text-gray-500">
        <h3 className="text-xl font-semibold mb-2">
          {searchTerm ? 'No medications found' : 'No medications added yet'}
        </h3>
        <p>
          {searchTerm
            ? `No medications match your search: "${searchTerm}"`
            : 'Add your first medication using the form above'}
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-2xl border border-gray-100 shadow-[0_24px_60px_-32px_rgba(79,70,229,0.28)]">
      <table className="w-full min-w-[1100px] bg-white">
        <thead className="bg-white/70 backdrop-blur border-b border-gray-100">
          <tr className="text-xs font-semibold uppercase tracking-[0.28em] text-gray-500">
            <th className="px-4 py-4 text-left">#</th>
            <th className="px-4 py-4 text-left">Medication</th>
            <th className="px-4 py-4 text-left">Dosage</th>
            <th className="px-4 py-4 text-left">Pharmacy Code</th>
            <th className="px-4 py-4 text-left">Main Stock</th>
            <th className="px-4 py-4 text-left">Quantity</th>
            <th className="px-4 py-4 text-left">Location</th>
            <th className="px-4 py-4 text-left">Expiration</th>
            <th className="px-4 py-4 text-left">Time Left</th>
            <th className="px-4 py-4 text-left">Status</th>
            <th className="px-4 py-4 text-left no-print">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {sortedMedications.map((med, index) => {
            const daysUntilExpiration = getDaysUntilExpiration(med.expirationDate);
            const status = getStatus(daysUntilExpiration);
            const expirationText = getExpirationText(daysUntilExpiration);

            return (
              <tr
                key={med.id}
                className={`transition-colors ${
                  status.rowClass === 'expired'
                    ? 'bg-rose-50/80'
                    : status.rowClass === 'expiring-soon'
                    ? 'bg-amber-50/80'
                    : index % 2 === 0
                    ? 'bg-white'
                    : 'bg-slate-50/80'
                } hover:bg-indigo-50/80`}
              >
                <td className="px-4 py-4 text-xs font-semibold text-gray-500">{index + 1}</td>
                <td className="px-4 py-4">
                  <div className="flex flex-col gap-1">
                    <span className="text-base font-semibold text-gray-900">{med.name}</span>
                    <span className="text-xs text-gray-500 uppercase tracking-[0.18em]">{med.pharmacyCode}</span>
                  </div>
                </td>
                <td className="px-4 py-4 text-sm text-gray-600">{med.dosage}</td>
                <td className="px-4 py-4 text-sm text-gray-600">{med.pharmacyCode}</td>
                <td className="px-4 py-4 text-sm text-gray-700 font-semibold">{med.mainStock}</td>
                <td className="px-4 py-4 text-sm text-gray-700 font-semibold">{med.quantity}</td>
                <td className="px-4 py-4 text-sm text-gray-600">
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white shadow-sm border border-gray-200 text-xs font-medium text-gray-600">
                    <span className="h-2 w-2 rounded-full bg-purple-400"></span>
                    {med.location}
                  </span>
                </td>
                <td className="px-4 py-4 text-sm text-gray-700">
                  {new Date(med.expirationDate).toLocaleDateString()}
                </td>
                <td className="px-4 py-4 text-sm font-medium">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                    {expirationText}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <span
                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold tracking-[0.12em] uppercase ${
                      status.class === 'status-good'
                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                        : status.class === 'status-warning'
                        ? 'bg-amber-100 text-amber-700 border border-amber-200'
                        : 'bg-rose-100 text-rose-700 border border-rose-200'
                    }`}
                  >
                    <span className="h-2 w-2 rounded-full bg-current"></span>
                    {status.text}
                  </span>
                </td>
                <td className="px-4 py-4 no-print">
                  <div className="flex gap-2 flex-wrap">
                    <button
                      onClick={() => setEditingId(med.id)}
                      className="px-3 py-1.5 bg-white text-cyan-600 border border-cyan-200 rounded-md text-sm font-semibold hover:bg-cyan-50 transition-colors flex items-center gap-1 shadow-sm"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      Edit
                    </button>
                    <button
                      onClick={() => onWithdraw(med.id)}
                      className="px-3 py-1.5 bg-orange-500 text-white rounded-md text-sm font-semibold shadow hover:shadow-md transition-all flex items-center gap-1"
                    >
                      <ArrowUpFromLine className="w-3.5 h-3.5" />
                      Withdraw
                    </button>
                    <button
                      onClick={() => onReturn(med.id)}
                      className="px-3 py-1.5 bg-blue-500 text-white rounded-md text-sm font-semibold shadow hover:shadow-md transition-all flex items-center gap-1"
                    >
                      <ArrowDownToLine className="w-3.5 h-3.5" />
                      Return
                    </button>
                    <button
                      onClick={() => handleDelete(med.id)}
                      className="px-3 py-1.5 bg-rose-500 text-white rounded-md text-sm font-semibold shadow hover:shadow-md transition-all flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
