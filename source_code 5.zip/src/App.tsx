import React, { useEffect, useState } from 'react';
import { useMedicationStore } from './store/medicationStore';
import { MedicationForm } from './components/MedicationForm';
import { MedicationList } from './components/MedicationList';
import { HistoryModal } from './components/HistoryModal';
import { useWithdrawReturnDialogs } from './components/WithdrawReturnDialogs';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Search, Printer, ClipboardList } from 'lucide-react';

const WELCOME_KEY = 'ot_med_tracker_welcome_seen';

function App() {
  const {
    loadFromStorage,
    saveToStorage,
    setSearchTerm,
    searchTerm,
    staffMember,
    setStaffMember,
  } = useMedicationStore();
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [saveIndicator, setSaveIndicator] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const { handleWithdraw, handleReturn } = useWithdrawReturnDialogs();

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const seen = window.localStorage.getItem(WELCOME_KEY);
    if (seen === 'true') {
      setShowWelcome(false);
    }
  }, []);

  useEffect(() => {
    loadFromStorage();
  }, [loadFromStorage]);

  // Auto-save every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      saveToStorage();
      setSaveIndicator(true);
      setTimeout(() => setSaveIndicator(false), 1000);
    }, 30000);

    return () => clearInterval(interval);
  }, [saveToStorage]);

  // Save before page unload
  useEffect(() => {
    const handleBeforeUnload = () => {
      saveToStorage();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [saveToStorage]);

  const handlePrint = () => {
    window.print();
  };

  const handleEnter = (staff: { name: string; staffID: string }) => {
    window.localStorage.setItem(WELCOME_KEY, 'true');
    setStaffMember(staff);
    setShowWelcome(false);
  };

  const handleSignOut = () => {
    window.localStorage.removeItem(WELCOME_KEY);
    setStaffMember(null);
    setShowWelcome(true);
  };

  if (showWelcome || !staffMember) {
    return <WelcomeScreen onEnter={handleEnter} />;
  }

  return (
    <div className="min-h-screen pb-16 pt-10 px-4 md:px-8 bg-[radial-gradient(circle_at_top,#f8f5ff_0%,#f1f5ff_50%,#f9fafb_100%)]">
      <div className="max-w-[1380px] mx-auto bg-white/90 backdrop-blur-xl rounded-[28px] shadow-[0_40px_80px_-40px_rgba(79,70,229,0.65)] border border-white/70 overflow-hidden">
        <div className="relative px-8 py-10 md:px-14 md:py-12 bg-gradient-to-br from-purple-600 via-indigo-600 to-purple-700 text-white">
          <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.4),transparent_55%)]"></div>
          <div className="relative flex flex-col items-center gap-3">
            <span className="text-xs uppercase tracking-[0.45em] text-white/70">Operating Theatre Suite</span>
            <h1 className="text-4xl md:text-[3.25rem] font-semibold text-center leading-tight">
              OT Medication Tracker
            </h1>
            <p className="text-center text-base md:text-lg text-white/80 max-w-2xl">
              Monitor medication stock, expirations, and patient-linked withdrawals with theatre-grade precision.
            </p>
          </div>
          <div className="absolute top-6 right-6 flex flex-col items-end gap-3">
            <div
              className={`bg-white/15 px-4 py-2 rounded-full text-xs md:text-sm font-medium flex items-center gap-2 shadow-sm transition-all duration-300 backdrop-blur-sm ${
                saveIndicator ? 'ring-2 ring-emerald-200/60 bg-emerald-400/20 text-white' : 'text-white/90'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full bg-emerald-300 shadow-[0_0_0_4px_rgba(16,185,129,0.2)] ${
                  saveIndicator ? 'animate-pulse' : 'animate-pulse-slow'
                }`}
              ></span>
              <span>Auto-save active</span>
            </div>
            <div className="bg-white/15 px-4 py-2 rounded-[18px] text-sm font-medium text-white/90 flex items-center gap-3 shadow-sm backdrop-blur-sm border border-white/20">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/25 font-semibold text-white">
                {staffMember.name.charAt(0).toUpperCase()}
              </span>
              <div className="flex flex-col leading-tight max-w-[160px]">
                <span className="truncate">{staffMember.name}</span>
                <span className="text-[11px] uppercase tracking-wide text-white/70">Staff ID {staffMember.staffID}</span>
              </div>
              <button
                onClick={handleSignOut}
                className="bg-white text-purple-700 text-xs font-semibold uppercase tracking-[0.18em] px-4 py-2 rounded-full shadow hover:bg-white/90 transition-colors"
              >
                Sign out
              </button>
            </div>
          </div>
        </div>

        <div className="p-6 md:p-10 lg:p-12">
          <MedicationForm />

          <div className="mb-6">
            <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Medication List</h2>
              
              <div className="flex flex-col sm:flex-row gap-3 flex-1 md:flex-initial">
                <div className="relative flex-1 md:w-96">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="🔍 Search by name, dosage, code, or location..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none transition-colors"
                  />
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => setIsHistoryOpen(true)}
                    className="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-all duration-200 hover:shadow-lg flex items-center gap-2 whitespace-nowrap"
                  >
                    <ClipboardList className="w-5 h-5" />
                    <span className="hidden sm:inline">Withdraw History</span>
                    <span className="sm:hidden">History</span>
                  </button>
                  
                  <button
                    onClick={handlePrint}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-all duration-200 hover:shadow-lg flex items-center gap-2 whitespace-nowrap"
                  >
                    <Printer className="w-5 h-5" />
                    <span className="hidden sm:inline">Print List</span>
                    <span className="sm:hidden">Print</span>
                  </button>
                </div>
              </div>
            </div>

            <MedicationList onWithdraw={handleWithdraw} onReturn={handleReturn} />
          </div>
        </div>
      </div>

      <HistoryModal isOpen={isHistoryOpen} onClose={() => setIsHistoryOpen(false)} />

      <style>{`
        @keyframes pulse-slow {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 2s infinite;
        }

        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @media print {
          body {
            background: white !important;
          }

          .no-print {
            display: none !important;
          }

          .bg-gradient-to-r {
            background: #667eea !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }

          .bg-gradient-to-br {
            background: white !important;
          }

          table {
            page-break-inside: auto;
          }

          tr {
            page-break-inside: avoid;
            page-break-after: auto;
          }

          .bg-red-50, .bg-yellow-50 {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
        }
      `}</style>
    </div>
  );
}

export default App;
