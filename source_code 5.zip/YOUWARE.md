# YOUWARE.md

This file provides guidance to YOUWARE Agent (youware.com) when working with code in this repository.

```markdown
# OT Medication Tracker - React Application

A comprehensive Operating Theatre Medication Management System built with React 18, TypeScript, Vite, and Tailwind CSS.

## Project Overview

This is a professional medical inventory management application designed for operating theatre environments. It provides complete medication tracking, expiration monitoring, and patient-linked withdrawal/return workflows with automatic data persistence.

## Project Status

- **Project Type**: React + TypeScript Modern Web Application
- **Entry Point**: `src/main.tsx` (React application entry)
- **Build System**: Vite 7.0.0 (Fast development and build)
- **Styling System**: Tailwind CSS 3.4.17 (Atomic CSS framework)
- **State Management**: Zustand 4.4.7 (Lightweight state management)
- **Storage**: localStorage with automatic backup system

## Core Features

### Medication Management
- Add, edit, and delete medications with comprehensive details
- Track medication name, dosage, pharmacy code, quantity, expiration date, and location
- Password-protected deletion (password: `De2255`)
- Support for standard locations (Room 1-7, Recovery 1-2) and custom locations
- Real-time search functionality across all medication fields

### Expiration Tracking
- Automatic calculation of days until expiration
- Visual status indicators:
  - **GOOD**: More than 30 days until expiration (green)
  - **EXPIRING SOON**: 30 days or less until expiration (yellow)
  - **EXPIRED**: Past expiration date (red)
- Color-coded table rows for quick visual identification
- Automatic sorting by expiration date (most urgent first)

### Withdrawal & Return System
- Patient-linked withdrawal tracking with patient name and ID
- Return functionality for unused medications
- Complete transaction history with all details
- Automatic quantity updates and validation
- Prevents over-withdrawal with quantity checks
- Undo support for recent history deletions (restores last deleted date range)

### Transaction History
- Comprehensive filterable history modal
- Filter by:
  - Medication name
  - Patient name
  - Patient ID
  - Date range (from/to)
  - Transaction type (withdraw/return)
- Color-coded transaction types
- Complete audit trail with timestamps
- Bulk delete history entries by date range with undo
- Print-ready layout

### Data Persistence
- Auto-save every 30 seconds
- Manual save before page unload
- Automatic backup creation
- Visual save indicator
- localStorage-based storage with backup system

### Print Functionality
- Print-optimized medication list
- Preserves color-coded status indicators
- Hides interactive elements in print view
- Professional print layout

## Tech Stack

### Core Framework
- **React**: 18.3.1 - Declarative UI library
- **TypeScript**: 5.8.3 - Type-safe JavaScript superset
- **Vite**: 7.0.0 - Next generation frontend build tool
- **Tailwind CSS**: 3.4.17 - Atomic CSS framework

### State Management & Storage
- **Zustand**: 4.4.7 - Lightweight state management
- **localStorage**: Browser-based persistent storage with automatic backups

### UI Components & Icons
- **Lucide React**: Beautiful icon library
- **Headless UI**: 1.7.18 - Unstyled UI components
- **Framer Motion**: 11.0.8 - Animation library

## Project Architecture

### Directory Structure

```
project-root/
├── src/
│   ├── App.tsx                    # Main application component
│   ├── main.tsx                   # Application entry point
│   ├── index.css                  # Global styles and Tailwind imports
│   ├── types/
│   │   └── index.ts              # TypeScript type definitions
│   ├── store/
│   │   └── medicationStore.ts    # Zustand store for state management
│   └── components/
│       ├── MedicationForm.tsx    # Add/edit medication form
│       ├── MedicationList.tsx    # Medication table with actions
│       ├── HistoryModal.tsx      # Transaction history modal with filters
│       └── WithdrawReturnDialogs.tsx  # Withdraw/return logic prompts
├── index.html                     # Main HTML template
├── package.json                   # Dependencies and scripts
├── vite.config.ts                # Vite configuration
├── tsconfig.json                 # TypeScript configuration
└── tailwind.config.js            # Tailwind CSS configuration
```

### Component Architecture

1. **App.tsx**: Main container component
   - Manages modal states
   - Handles print functionality
   - Coordinates auto-save
   - Integrates all sub-components

2. **MedicationForm.tsx**: Form component
   - Collapsible form with smooth animations
   - Handles both add and edit modes
   - Custom location support
   - Form validation

3. **MedicationList.tsx**: Table component
   - Displays sorted medications
   - Color-coded status indicators
   - Action buttons (Edit, Withdraw, Return, Delete)
   - Password-protected deletion

4. **HistoryModal.tsx**: History modal component
   - Full-screen filterable modal
   - Multiple filter options
   - Displays transaction details
   - Patient information for withdrawals
   - Print and delete-by-range controls
   - Undo option for the most recent deletion

5. **WithdrawReturnDialogs.tsx**: Dialog logic hook
   - Handles withdraw prompts with patient info
   - Handles return prompts
   - Input validation
   - Success/error feedback

### State Management (Zustand Store)

**Store Location**: `src/store/medicationStore.ts`

**State Structure**:
```typescript
{
  medications: Medication[]
  withdrawHistory: WithdrawTransaction[]
  lastDeletedHistory: WithdrawTransaction[]
  lastDeletionRange: { from: string; to: string } | null
  searchTerm: string
  editingId: string | null
}
```

**Key Actions**:
- `addMedication()`: Add new medication
- `updateMedication()`: Update existing medication
- `deleteMedication()`: Remove medication
- `withdrawMedication()`: Process withdrawal with patient info
- `returnMedication()`: Process return
- `clearHistoryByDateRange()`: Delete history entries within range and store undo snapshot
- `undoLastHistoryDeletion()`: Restore last deleted entries if available
- `setSearchTerm()`: Update search filter
- `loadFromStorage()`: Load from localStorage
- `saveToStorage()`: Save to localStorage with backup
- `getFilteredMedications()`: Get search-filtered medications

### Type Definitions

**Location**: `src/types/index.ts`

**Main Types**:
- `Medication`: Core medication data structure
- `WithdrawTransaction`: Transaction record with patient info
- `MedicationStatus`: Status classification (good/warning/expired)
- `LocationOption`: Available location options

## Development Commands

- **Install dependencies**: `npm install`
- **Build project**: `npm run build`
- **Development mode**: `npm run dev` (Use only for local development)

## Security Features

- Password-protected deletion (`De2255`)
- Three-attempt limit for deletion password
- Input validation on all forms
- Quantity validation for withdrawals
- Patient information required for withdrawals
- Undo support prevents accidental loss of history data

## Storage Strategy

### localStorage Keys:
- `medications`: Current medication list
- `withdrawHistory`: Transaction history
- `medications_backup`: Backup of medications
- `withdrawHistory_backup`: Backup of history
- `last_save_time`: Timestamp of last save

### Auto-Save System:
- Saves every 30 seconds
- Saves before page unload
- Creates automatic backups
- Visual feedback on save

## Design Philosophy

### Color Palette
- **Primary Gradient**: Purple to Indigo (`from-purple-600 to-indigo-600`)
- **Status Colors**:
  - Green: Good status
  - Yellow: Warning status
  - Red: Expired status
- **Clean White Background**: Professional medical interface

### User Experience
- Smooth animations for form transitions
- Hover effects on interactive elements
- Clear visual feedback for all actions
- Responsive design for mobile and desktop
- Print-optimized layout

## Critical Files - DO NOT MODIFY

### ⚠️ index.html Entry Point
**WARNING**: Never modify this line in `index.html`:
```html
<script type="module" src="/src/main.tsx"></script>
```

This is the Vite entry point. Any modification will break the application.

## Configuration Files

- `vite.config.ts` - Vite configuration
- `tsconfig.json` - TypeScript configuration
- `tailwind.config.js` - Tailwind CSS configuration
- `postcss.config.js` - PostCSS configuration

## Medical Workflow Notes

1. **Adding Medications**: Use the collapsible form to add medications with all required details
2. **Monitoring Expiration**: Table automatically sorts by expiration date with color coding
3. **Withdrawing for Patients**: Click "Withdraw" → Enter patient name → Enter patient ID → Enter quantity
4. **Returning Unused Medications**: Click "Return" → Enter quantity to return
5. **Viewing History**: Click "Withdraw History" to view and filter all transactions
6. **Deleting History Range**: Select From/To dates → Click "Delete Range" → Undo available immediately after deletion
7. **Printing**: Click "Print" within the history modal or main list for reports
8. **Searching**: Use search box to filter by any medication field

## Future Enhancements Considerations

- Backend integration for multi-user access
- Barcode scanning support
- Medication usage analytics
- Low stock alerts
- Prescription integration
- Export to CSV/PDF
- Role-based access control
```
